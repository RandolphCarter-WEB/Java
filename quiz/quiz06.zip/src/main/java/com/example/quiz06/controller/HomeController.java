package com.example.quiz06.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.rmi.server.ServerCloneException;

@Controller
public class HomeController {
    @PostMapping(value = "/")
    public String printUserInfo(HttpServletRequest req, HttpServletResponse resp) throws ServerCloneException, UnsupportedEncodingException {
        System.out.println("[UserInfoPrint] System Load");

        req.setCharacterEncoding("UTF-8");
        String education = req.getParameter("education");
        String username = req.getParameter("userName");
        String useremail = req.getParameter("userEmail");
        String password = req.getParameter("password");
        String department = req.getParameter("department");
        String gender = req.getParameter("gender");
        String interest = req.getParameter("interest");

        System.out.println("[SYSTEM Info] " + education);
        System.out.println("[SYSTEM] UserName >> " + username);
        System.out.println("[SYSTEM] UserEmail >> " + useremail);
        System.out.println("[SYSTEM] Password >> " + password);
        System.out.println("[SYSTEM] User Department >> " + department);
        System.out.println("[SYSTEM] gender >> " + gender);
        System.out.println("[SYSTEM] interest >> " + interest);

        return "index";
    }
}
