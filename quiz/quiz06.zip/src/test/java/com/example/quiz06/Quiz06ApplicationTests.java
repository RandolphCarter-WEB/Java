package com.example.quiz06;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Quiz06ApplicationTests {

    @Test
    void contextLoads() {
    }

}
